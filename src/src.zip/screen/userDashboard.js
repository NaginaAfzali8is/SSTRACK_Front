import React, { useEffect, useState } from "react";
import line from "../images/line.webp";
import check from "../images/online.webp";
import screenshot from "../images/white.svg";
import setting from "../images/setting.webp";
import { useNavigate } from "react-router-dom";
import Skeleton from "react-loading-skeleton";
import 'react-loading-skeleton/dist/skeleton.css';
import useLoading from "../hooks/useLoading";
import axios from "axios";
import offline from "../images/not-active.svg";
import moment from 'moment-timezone';
// import socket from '../io';
import { io } from 'socket.io-client'; // Correct import
import { useSocket } from '../io'; // Correct import


function UserDashboard() {
    const [activeUser, setActiveUser] = useState(null);
    const { loading, setLoading } = useLoading();
    const [data, setData] = useState(null);
    const [data2, setData2] = useState([]);
    const [sortOrder, setSortOrder] = useState('asc');
    const [lastActiveSortOrder, setLastActiveSortOrder] = useState('asc');
    const [todaySortOrder, setTodaySortOrder] = useState('asc');
    const [yesterdaySortOrder, setYesterdaySortOrder] = useState('asc');
    const [thisWeekSortOrder, setThisWeekSortOrder] = useState('asc');
    const [thisMonthSortOrder, setThisMonthSortOrder] = useState('asc');
    const [socketData, setSocketData] = useState(null); // State to store data from socket
    const navigate = useNavigate();
    const socket = useSocket()

    const getManagerData = async () => {
        setLoading(true)
        try {
            const response = await axios.get(`https://myuniversallanguages.com:9093/api/v1/manager/dashboard`, {
                headers: headers,
            })
            if (response.status) {
                setLoading(false)
                const onlineUsers = response.data?.onlineUsers?.length > 0 ? response.data?.onlineUsers : []
                const offlineUsers = response.data?.offlineUsers?.length > 0 ? response.data?.offlineUsers : []
                const allUsers = [...onlineUsers, ...offlineUsers];
                setData2(allUsers.filter((f) => f.isArchived === false && f.UserStatus === false))
            }
        } catch (error) {
            setLoading(false)
            console.log(error);
        }
    }

    const getOwnerData = async () => {
        setLoading(true)
        try {
            const response = await axios.get(`https://myuniversallanguages.com:9093/api/v1/owner/getCompanyemployee`, {
                headers: headers,
            })
            if (response.status) {
                setLoading(false)
                const onlineUsers = response.data?.onlineUsers?.length > 0 ? response.data?.onlineUsers : []
                const offlineUsers = response.data?.offlineUsers?.length > 0 ? response.data?.offlineUsers : []
                const allUsers = [...onlineUsers, ...offlineUsers];
                console.log(response.data);
                setData2(allUsers.filter((f) => f.isArchived === false && f.UserStatus === false))
            }
        } catch (error) {
            setLoading(false)
            console.log(error);
        }
    }

    async function getUserData() {
        setLoading(true)
        try {
            const response = await axios.get(`${apiUrl}/timetrack/hours`, {
                headers,
            })
            if (response.status) {
                setData(response.data)
                setLoading(false)
                console.log(response);
            }
        }
        catch (error) {
            setLoading(false)
            console.log(error);
        }
    }



    useEffect(() => {
        if (!socket) {
            console.error('Socket instance is null or undefined');
            return;
        }

        const handleNewSS = (data) => {
            console.log("New data received from socket:", data);
            setData2(prevData => {
                    const updatedData = prevData.map(user =>
                        user.userId === data.user_id && user.recentScreenshot.key === data.key
                            ? { ...user, recentScreenshot: user.recentScreenshot.key, minutesAgo: user.minutesAgo }
                            : user
                    );
                console.log("Updated data:", updatedData);
                return updatedData;
            });
        };

        socket.on('new-ss', handleNewSS);

        return () => {
            socket.off('new-ss', handleNewSS);
        };
    }, [socket]);




    const token = localStorage.getItem('token');
    const user = JSON.parse(localStorage.getItem('items'));
    const headers = {
        Authorization: 'Bearer ' + token,
    };


    const apiUrl = "https://myuniversallanguages.com:9093/api/v1";

    const fetchData = async () => {
        setLoading(true);
        try {
            let endpoint;
            if (user?.userType === "user") {
                endpoint = `${apiUrl}/timetrack/hours`;
            } else if (user?.userType === "owner" || user?.userType === "admin") {
                endpoint = `${apiUrl}/owner/getCompanyemployee`;
            } else if (user?.userType === "manager") {
                endpoint = `${apiUrl}/manager/dashboard`;
            }
            const response = await axios.get(endpoint, { headers });
            if (response.status === 200) {
                setLoading(false);
                const onlineUsers = response.data?.onlineUsers || [];
                const offlineUsers = response.data?.offlineUsers || [];
                const allUsers = [...onlineUsers, ...offlineUsers];
                const filteredUsers = allUsers.filter(f => !f.isArchived && !f.UserStatus);
                setData2(filteredUsers);
            }
        } catch (error) {
            setLoading(false);
            console.error(error);
        }
    };

    useEffect(() => {
        fetchData();
    }, [user?.userType]);

    const items = JSON.parse(localStorage.getItem('items'));
    const offsetInMinutes = moment.tz(items?.timezone).utcOffset();
    const offsetInHours = offsetInMinutes / 60;
    const offsetSign = offsetInHours >= 0 ? '+' : '-';
    const formattedOffset = `${offsetSign}${Math.abs(offsetInHours)}`;

    // Helper function to convert time description to minutes
    const convertToMinutes = (description) => {
        if (description.includes('minute')) return parseInt(description);
        if (description.includes('hour')) return parseInt(description) * 60;
        if (description.includes('day')) return parseInt(description) * 1440;
        if (description.includes('week')) return parseInt(description) * 10080;
        if (description.includes('month')) return parseInt(description) * 43200;
        return 0;
    };

    // Function to handle sorting of employees by name
    const handleSort = () => {
        const sorted = [...data2].sort((a, b) => {
            const nameA = a.userName.toUpperCase();
            const nameB = b.userName.toUpperCase();
            return sortOrder === 'asc' ? nameA.localeCompare(nameB) : nameB.localeCompare(nameA);
        });
        setData2(sorted);
        setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    };

    // Function to handle sorting of employees by last active time
    const handleLastActiveSort = () => {
        const sorted = [...data2].sort((a, b) => {
            const minutesA = convertToMinutes(a.minutesAgo);
            const minutesB = convertToMinutes(b.minutesAgo);
            return lastActiveSortOrder === 'asc' ? minutesA - minutesB : minutesB - minutesA;
        });
        setData2(sorted);
        setLastActiveSortOrder(lastActiveSortOrder === 'asc' ? 'desc' : 'asc');
    };

    // Function to handle sorting of employees by today's data
    const handleTodaySort = () => {
        const sorted = [...data2].sort((a, b) => {
            const todayHoursA = a.totalHours?.daily || 0;
            const todayHoursB = b.totalHours?.daily || 0;
            return todaySortOrder === 'asc' ? todayHoursA - todayHoursB : todayHoursB - todayHoursA;
        });
        setData2(sorted);
        setTodaySortOrder(todaySortOrder === 'asc' ? 'desc' : 'asc');
    };

    // Function to handle sorting of employees by yesterday's data
    const handleYesterdaySort = () => {
        const sorted = [...data2].sort((a, b) => {
            const yesterdayHoursA = a.totalHours?.yesterday || 0;
            const yesterdayHoursB = b.totalHours?.yesterday || 0;
            return yesterdaySortOrder === 'asc' ? yesterdayHoursA - yesterdayHoursB : yesterdayHoursB - yesterdayHoursA;
        });
        setData2(sorted);
        setYesterdaySortOrder(yesterdaySortOrder === 'asc' ? 'desc' : 'asc');
    };

    // Function to handle sorting of employees by this week's data
    const handleThisWeekSort = () => {
        const sorted = [...data2].sort((a, b) => {
            const thisWeekHoursA = a.totalHours?.weekly || 0;
            const thisWeekHoursB = b.totalHours?.weekly || 0;
            return thisWeekSortOrder === 'asc' ? thisWeekHoursA - thisWeekHoursB : thisWeekHoursB - thisWeekHoursA;
        });
        setData2(sorted);
        setThisWeekSortOrder(thisWeekSortOrder === 'asc' ? 'desc' : 'asc');
    };

    // Function to handle sorting of employees by this month's data
    const handleThisMonthSort = () => {
        const sorted = [...data2].sort((a, b) => {
            const thisMonthHoursA = a.totalHours?.monthly || 0;
            const thisMonthHoursB = b.totalHours?.monthly || 0;
            return thisMonthSortOrder === 'asc' ? thisMonthHoursA - thisMonthHoursB : thisMonthHoursB - thisMonthHoursA;
        });
        setData2(sorted);
        setThisMonthSortOrder(thisMonthSortOrder === 'asc' ? 'desc' : 'asc');
    };

    return (
        <div>
            <div className="container">
                <div className="userHeader">
                    <div>
                        <h5>Employee Dashboard</h5>
                    </div>
                    <div className="headerTop">
                        <h6>All times are UTC {formattedOffset}</h6>
                        <img src={setting} alt="setting.png" style={{ cursor: "pointer" }} onClick={() => navigate("/account")} />
                    </div>
                </div>
                <div className="mainwrapper">
                    <div className="userDashboardContainer">
                        <div className="dashheadings">
                            <p
                                style={{ fontSize: "18px", color: "#0D3756", cursor: "pointer" }}
                                className="dashheadingtop"
                                onClick={handleSort}
                            >
                                Employee {sortOrder === 'asc' ? '↑' : '↓'}
                            </p>
                            <p
                                style={{ fontSize: "18px", color: "#0D3756", cursor: "pointer" }}
                                className="dashheadingtop textalign"
                                onClick={handleLastActiveSort}
                            >
                                Last active {lastActiveSortOrder === 'asc' ? '↑' : '↓'}
                            </p>
                            <p
                                style={{ fontSize: "18px", color: "#0D3756", cursor: "pointer" }}
                                className="dashheadingtop textalign"
                                onClick={handleTodaySort}
                            >
                                Today {todaySortOrder === 'asc' ? '↑' : '↓'}
                            </p>
                            <p
                                style={{ fontSize: "18px", color: "#0D3756", cursor: "pointer" }}
                                className="dashheadingtop textalign"
                                onClick={handleYesterdaySort}
                            >
                                Yesterday {yesterdaySortOrder === 'asc' ? '↑' : '↓'}
                            </p>
                            <p
                                style={{ fontSize: "18px", color: "#0D3756", cursor: "pointer" }}
                                className="dashheadingtop textalign"
                                onClick={handleThisWeekSort}
                            >
                                This week {thisWeekSortOrder === 'asc' ? '↑' : '↓'}
                            </p>
                            <p
                                style={{ fontSize: "18px", color: "#0D3756", cursor: "pointer" }}
                                className="dashheadingtop textalign"
                                onClick={handleThisMonthSort}
                            >
                                This month {thisMonthSortOrder === 'asc' ? '↑' : '↓'}
                            </p>
                        </div>
                        {loading ? (
                            <>
                                <Skeleton count={1} height="107px" style={{ margin: "0 0 10px 0" }} />
                                <Skeleton count={1} height="107px" style={{ margin: "0 0 10px 0" }} />
                                <Skeleton count={1} height="107px" style={{ margin: "0 0 10px 0" }} />
                                <Skeleton count={1} height="107px" style={{ margin: "0 0 10px 0" }} />
                                <Skeleton count={1} height="107px" style={{ margin: "0 0 10px 0" }} />
                                <Skeleton count={1} height="107px" style={{ margin: "0 0 10px 0" }} />
                            </>
                        ) : (
                            <>
                                {user?.userType === "user" ? (
                                    <div onClick={() => navigate(`/timeline`)} className={`dashsheadings ${data?.isActive === true ? "activeColorChange" : "bgColorChange"}`} key={data?.userId}>
                                        <div className="companyNameverified">
                                            <img src={activeUser?.isActive ? check : data?.data?.isActive ? check : offline} alt="Verified" />
                                            <h5 className="dashCompanyName">{data?.data?.name}</h5>
                                        </div>
                                        <div className="companyNameverified lastActive" style={{ width: "100%" }}>
                                            <img
                                                className="screenShotPreview"
                                                src={data?.data?.lastScreenshot?.key ? data?.data?.lastScreenshot?.key : screenshot}
                                                alt="Screenshot"
                                            />
                                            <p className="dashheadingtop">
                                                ({data?.data?.lastActiveTime === "0 minutes ago" ? "a minute ago" : data?.data?.lastActiveTime})
                                            </p>
                                        </div>
                                        <div className="nameVerified">
                                            <p className="dashheadingtop textalign">{data?.data?.totalHours?.daily}</p>
                                            <p className="screenShotAmount" style={{ color: data?.isActive === false && "#28659C" }}>${data?.data?.billingAmounts?.daily}</p>
                                        </div>
                                        <div className="nameVerified">
                                            <p className="dashheadingtop textalign">{data?.data?.totalHours?.yesterday}</p>
                                            <p className="screenShotAmount" style={{ color: data?.isActive === false && "#28659C" }}>${data?.data?.billingAmounts?.yesterday}</p>
                                        </div>
                                        <div className="nameVerified">
                                            <p className="dashheadingtop textalign">{data?.data?.totalHours?.weekly}</p>
                                            <p className="screenShotAmount" style={{ color: data?.isActive === false && "#28659C" }}>${data?.data?.billingAmounts?.weekly}</p>
                                        </div>
                                        <div className="nameVerified">
                                            <p className="dashheadingtop textalign">{data?.data?.totalHours?.monthly}</p>
                                            <p className="screenShotAmount" style={{ color: data?.isActive === false && "#28659C" }}>${data?.data?.billingAmounts?.monthly}</p>
                                        </div>
                                    </div>
                                ) : (
                                    data2.map((user, index) => (
                                        <div className="dashsheadings" key={user?.userId} onClick={() => navigate(`/timeline/${user?.userId}`)}>
                                            <div className="companyNameverified">
                                                <img src={user?.userId === activeUser?._id && activeUser?.isActive === true ? check : user?.isActive === true ? check : offline} alt="Verified" />
                                                <h5 className="dashCompanyName">{user?.userName}</h5>
                                            </div>
                                            <div key={user.userId} className="companyNameverified lastActive" style={{ width: "100%" }}>
                                                <img
                                                    className="screenShotPreview"
                                                    src={user.recentScreenshot && user.recentScreenshot.key ? user.recentScreenshot.key : 'default-screenshot-url'}
                                                    alt="Screenshot"
                                                />
                                                <p className="dashheadingtop">
                                                    ({user.minutesAgo === "0 minutes ago" ? "a minute ago" : user.minutesAgo})
                                                </p>
                                            </div>

                                            {/* <div className="companyNameverified lastActive" style={{ width: "100%" }}>
                                                {socketData && socketData.recentScreenshot && socketData.recentScreenshot.key ? (
                                                    <img src={socketData.recentScreenshot.key} alt="Screenshot" style={{ width: '100px' }} />
                                                ) : (
                                                    <span>No screenshot available</span>
                                                )}

                                                <p className="dashheadingtop">
                                                    {socketData && socketData.data && (

                                                        socketData.data.lastActiveTime === "0 minutes ago" ? "a minute ago" : socketData.data.lastActiveTime
                                                    )}
                                                </p>
                                            </div> */}


                                            <div className="nameVerified">
                                                <p className="dashheadingtop textalign">{user?.totalHours?.daily}</p>
                                                <p className="screenShotAmount" style={{ color: user?.isActive === true && "#28659C" }}>${user?.billingAmounts?.daily}</p>
                                            </div>
                                            <div className="nameVerified">
                                                <p className="dashheadingtop textalign">{user?.totalHours?.yesterday}</p>
                                                <p className="screenShotAmount" style={{ color: user?.isActive === true && "#28659C" }}>${user?.billingAmounts?.yesterday}</p>
                                            </div>
                                            <div className="nameVerified">
                                                <p className="dashheadingtop textalign">{user?.totalHours?.weekly}</p>
                                                <p className="screenShotAmount" style={{ color: user?.isActive === true && "#28659C" }}>${user?.billingAmounts?.weekly}</p>
                                            </div>
                                            <div className="nameVerified">
                                                <p className="dashheadingtop textalign">{user?.totalHours?.monthly}</p>
                                                <p className="screenShotAmount" style={{ color: user?.isActive === true && "#28659C" }}>${user?.billingAmounts?.monthly}</p>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </>
                        )}

                    </div>
                </div>
            </div>
            <img className="userDasboardLine" src={line} alt="line" />
        </div>
    );
}

export default UserDashboard;
