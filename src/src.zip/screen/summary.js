import React from "react";

function SummaryReport() {
    return (
      <div></div>
    )
}

export default SummaryReport;